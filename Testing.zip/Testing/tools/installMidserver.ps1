# =============================================================================================================
# Install and start a new Midserver copying the parameters from an existing Midserver
# and modifying some parameters to maker them unique
#
# Parameters:
#    - midSnowName : existing Midservername in SNOW  from where to copy all parameters
#    - instance    : Can be given, and must be given, if the different, new SNOW instance (cssnowsand9)
#    - user        : Can be given, if different than in midSnowName
#    - pw          : Can be given, if different than in midSnowName
#    - url         : Can be given, if requirement specific Midserver Download zip
#    - version     : default kingston, others helsinki, jakarta
#    - download    : boolean - download or use already downloaded zip, default = true = download
#    - start       : boolean - install (InstallMID-NT.bat )and start (StartMID-NT.bat) the new Midserver, default = true ( = install and start)
#
# Functionality:
#    - Check and write Mutex
#    - Collect all parameters from existing Midserver to mid.xml
#    - If instance name is given, adjust the parameters in mid.xml
#    - Make parameters unique in mid.xml
#    - Download Midserver zip
#    - Configure config.xml using mid.xml
#    - Configure override config using mid.xml
#    - Check Windows service (should not be already installed)
#    - InstallMID-NT.bat
#    - StartMID-NT.bat
#    - Remove Mutex
#
# Example: C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe G:\ServiceNow\tools\installMidserver.ps1 'MID Server SBX1_1'
#          C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe G:\ServiceNow\tools\installMidserver.ps1 'MID Server SBX1_1' -download $true -start $false
#          C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe G:\ServiceNow\tools\installMidserver.ps1 'MID Server SBX1_1' 'cssnowsand9' 'midserversand1' 'mid.server.sand1' 'kingston' -download $false -start $false
#          C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe G:\ServiceNow\tools\installMidserver.ps1 'MID Server SBX1_1' '' '' 'mid.server.sand1'
#          C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe G:\ServiceNow\tools\installMidserver.ps1 'MID Server SBX1_1' '' '' 'mid.server.sand1' 'https://install.service-now.com/glide/distribution/builds/package/mid/2018/01/03/mid.kingston-10-17-2017__patch1-12-12-2017_01-03-2018_0843.windows.x86-64.zip'
#
# =============================================================================================================
Param(
  [Parameter(Mandatory=$true)]
  [string]$midSnowName
 ,[Parameter(Mandatory=$false)]
  [string]$instance = ""
 ,[Parameter(Mandatory=$false)]
  [string]$user = ""
 ,[Parameter(Mandatory=$false)]
  [string]$pw = ""
 ,[Parameter(Mandatory=$false)]
  [string]$url = ""
 ,[Parameter(Mandatory=$false)]
  [string]$version = "kingston"
 ,[Parameter(Mandatory=$false)]
  [bool]$download = $true
 ,[Parameter(Mandatory=$false)]
  [bool]$start = $true
)
#. .\defs.ps1
[string]$midRoot  = "G:\ServiceNow\";
[string]$midTools = $midRoot + "tools\"
[string]$myLog    = $midTools + "install.log"
[string]$myMutex  = $midTools + "mutex.mtx"
[string]$host     = hostname
$logTime = Get-Date -Format "yyyy-MM-dd hh:mm:ss"

# save call parameters
[string]$instanceParam = $instance
[string]$userParam     = $user
[string]$pwParam       = $pw

[bool]$global:midStatus = $true
$logTime = Get-Date -Format "yyyy-MM-dd hh:mm:ss"
Add-Content $myLog "$logTime --------------------------------------------------------------------------------------------"
Add-Content $myLog "$logTime CALL PARAM: MidServer $midSnowName"
Add-Content $myLog "$logTime      PARAM: Download  $download"
Add-Content $myLog "$logTime      PARAM: Start     $start"
if ( $instance -ne "" )
{
	Add-Content $myLog "$logTime      PARAM: instance  $instance"
}
if ( $user -ne "" )
{
	Add-Content $myLog "$logTime      PARAM: user      $user"
}
if ( $pw -ne "" )
{
	Add-Content $myLog "$logTime      PARAM: pw        $pw"
}
if ( $url -ne "" )
{
	Add-Content $myLog "$logTime      PARAM: url       $url"
}
if ( $pw -ne "" )
{
	Add-Content $myLog "$logTime      PARAM: version   $version"
}

[string]$tempXml     = "temp.xml"
[string]$midXml      = "mid.xml"
[string]$fullMidXml  = $midTools + "mid.xml"

# --------------------------------------------
# - check and create Mutex
# --------------------------------------------
if ( $global:midStatus -eq $true )
{
	# Mutex file exists
	If ( test-path $myMutex )
	{
		# Ignore old ( = over 15 mins old ) mutex file
        $mtxCnt = (Get-ChildItem -Path G:\ServiceNow\tools\ -Filter *.mtx | ? {$_.LastWriteTime -gt (Get-Date).AddMinutes(-15)} | Measure-Object).Count;
		if ( $mtxCnt > 0 )
		{
			Write-Output "$logTime Mutex check failed, please try 15 minutes later"
			Add-Content $myLog "$logTime Mutex check failed, please try 15 minutes later"
			$global:midStatus = $false	
		}
		else
		{
			Add-Content $myLog   "$logTime Found old mutex, ignored, Mutex created"
			Add-Content $myMutex "$logTime Found old mutex, ignored, Mutex created"
		}
	}
	else
	{
		# Create Mutex file
		Add-Content $myLog   "$logTime Mutex created"
		Add-Content $myMutex "$logTime Mutex created"
	}
}

# $global:midStatus = $false

# --------------------------------------------
# - create mid.xml from an existing Midserver
# --------------------------------------------
if ( $global:midStatus -eq $true )
{
    G:\ServiceNow\tools\createConfigXml.ps1 "$midSnowName" $tempXml
}

# ----------------------------------------------------------
# - if new instance name is given, we modify some parameters
# ----------------------------------------------------------
if ( $global:midStatus -eq $true )
{
	if ( $instanceParam -ne "" )
	{
		G:\ServiceNow\tools\adjustNewInstance.ps1 $tempXml $instance
	}
}

#$global:midStatus = $false

# --------------------------------------------
# - Modify parameters to make names and folder unique
# --------------------------------------------
if ( $global:midStatus -eq $true )
{
    G:\ServiceNow\tools\adjustConfigXml.ps1 $tempXml $midXml
}

#$global:midStatus = $false

# --------------------------------------------
# - Download Midserver zip to a new Midserver folder
# --------------------------------------------

if ( $global:midStatus -eq $true )
{
	G:\ServiceNow\tools\DownloadMidServer $midXml -version $version -url $url -download $download
}

#$global:midStatus = $false

# --------------------------------------------
# - parse XML parameters
# --------------------------------------------


if ( $global:midStatus -eq $true )
{
    [string]$folder = ""
    [string]$instance = ""
    [string]$user = ""
    [string]$pw = ""
    [string]$name = ""
    [string]$service = ""
    [string]$display = ""
    [string]$display = ""
    [string]$javaAgent = ""
    [string]$appName = ""
    [string]$tierName = ""
    [string]$nodeName = ""
    
    $rootDir = "G:\ServiceNow\"
    $file = $rootDir + $xmlFile
    [xml]$XmlDocument = Get-Content -Path $fullMidXml
    foreach ( $par in $XmlDocument.Parameters.Parameter )
    {
        $key = $par.name
        $val = $par.value
        if ( $key -eq "folder" )     { $folder    = $val }
        if ( $key -eq "instance" )   { $instance  = $val }
        if ( $key -eq "user" )       { $user      = $val }
        if ( $key -eq "pw" )         { $pw        = $val }
        if ( $key -eq "name" )       { $name      = $val }
        if ( $key -eq "service" )    { $service   = $val }
        if ( $key -eq "display" )    { $display   = $val }
        if ( $key -eq "javaAgent" )  { $javaAgent = $val }
        if ( $key -eq "appName" )    { $appName   = $val }
        if ( $key -eq "tierName" )   { $tierName  = $val }
        if ( $key -eq "nodeName" )   { $nodeName  = $val }
    }
	
	# Override Midserver params with call params, if given
	if ( $userParam -ne "" )
	{
		$user = $userParam
	}
	if ( $pwParam -ne "" )
	{
		$pw = $pwParam
	}
}

# --------------------------------------------
# - configure config.xml
# --------------------------------------------
if ( $global:midStatus -eq $true )
{
    G:\ServiceNow\tools\configureConfigXml.ps1 $folder `
                                               $instance `
                                               $user `
                                               $pw `
                                               "$name"
}
                            
# --------------------------------------------
# - configure wrapper-override.conf
# --------------------------------------------
if ( $global:midStatus -eq $true )
{
    G:\ServiceNow\tools\configureOverride.ps1  $folder `
                                               $service `
                                               "$display" `
                                               "$display" `
                                               $javaAgent `
                                               $appName `
                                               $tierName `
                                               "$nodeName"
}
                            
							
# --------------------------------------------
# - Check service 
# --------------------------------------------
if ( $global:midStatus -eq $true )
{
	$winService = Get-Service -Name "$service" -ErrorAction SilentlyContinue							
	if ( $winService.Length -gt 0 ) 
	{
		Write-Output "MidServer service $service already exists, installation cancelled"
		Add-Content $myLog "$logTime MidServer service $service already exists, installation cancelled"
		$global:midStatus = $false
    }
}
						
# --------------------------------------------
# - install and start Midserver
# --------------------------------------------
if ( $global:midStatus -eq $true )
{
    if ( $start -eq $true )
    {
        $binFolder     = $midRoot + "\" + $folder + '\agent\bin\'
        $binInstallBat = $binFolder + 'InstallMID-NT.bat'
        $binStartBat   = $binFolder + 'StartMID-NT.bat'
		Add-Content $myLog "$logTime InstallMID-NT.bat"
        $output = cmd.exe /c $binInstallBat                           
		Add-Content $myLog "$logTime $output"
		Add-Content $myLog "$logTime StartMID-NT.bat"
        $output = cmd.exe /c $binStartBat                    
		Add-Content $myLog "$logTime $output"
    }
}

# --------------------------------------------
# - Write install status
# --------------------------------------------
if ( $global:midStatus -eq $true )
{	
	$logTime = Get-Date -Format "yyyy-MM-dd hh:mm:ss"
	[string]$createdBy = $midRoot + $folder + "\CreatedByInstallMidserver.txt"
	Add-Content $createdBy "$logTime created from Midserver $midSnowName"
    if ( $start -eq $true )
    {
		Write-Output "MidServer $name installed and started"
		Add-Content $myLog "$logTime $name installed and started"
	}
	else
    {
		Write-Output "MidServer $name created"
		Add-Content $myLog "$logTime $name created"
	}
}
                                   
# --------------------------------------------
# - Remove Mutex
# --------------------------------------------
If ( test-path $myMutex )
{
	Remove-Item $myMutex
	$logTime = Get-Date -Format "yyyy-MM-dd hh:mm:ss"
	Add-Content $myLog   "$logTime Mutex removed"
}
								   								   