# =============================================================================================================
#  Delete Midserver
#  Parameters:
#       - midserverName   : Name of existing Midserver name on SNOW side (example: MID Server SBX1_98_4)
#  Usage:
#  - Example: .\deleteMidserver.ps1 'MID Server SBX1_98_4'
# =============================================================================================================
Param(
  [Parameter(Mandatory=$true)]
  [string]$midserverName
)
[string]$midRoot  = "G:\ServiceNow\";
[string]$midTools = $midRoot + "tools\"
[string]$myLog    = $midTools + "install.log"
$logTime = Get-Date -Format "yyyy-MM-dd hh:mm:ss"
[bool]$global:midStatus = $true

$folder = ""
[string]$configFile = ""
Add-Content $myLog "$logTime --------------------------------------------------------------------------------------------"
Add-Content $myLog "$logTime DELETE MIDSERVER: CALL PARAM: MidServer $midserverName"

# ---------------------------------------
# Check the name what we can delete
# ---------------------------------------
if ( $global:midStatus -eq $true )
{
	[string]$host      = hostname
	[string]$shortHost = $host.Substring($host.Length - 2, 2);
	[string]$toMatch = "*_" + $shortHost + "_*"
	if ( ! ($midserverName -like $toMatch) )
	{
		Add-Content $myLog "$logTime DELETE MIDSERVER: It is not allowed to delete Midserver $midserverName"	
		Write-Output "$logTime It is not allowed to delete Midserver $midserverName"	
		$global:midStatus = $false
	}
}

# ---------------------------------------
# Search folder name from midname in SNOW
# ---------------------------------------
if ( $global:midStatus -eq $true )
{
	[bool]$midFound = $false
	$lines = Get-ChildItem 'G:\ServiceNow\*\config.xml' -recurse | Select-String -Pattern 'name="name"'
	foreach ( $line in $lines )
	{
		[string]$li = [string]$line;
		[string]$str1 = $li.split('=')[2]
		[string]$midName = $str1.split('"')[1]
		
		if ( ! ($li -like "*archive*" ) -and $li -like "*$midserverName*"  )
		{
			$folder  = [string]$li.split("\")[2]
			$configFile = $midRoot + $folder + "\agent\config.xml"
			$midFound = $true
		}
	}
	if ( $midFound -eq $false )
	{
		Add-Content $myLog "$logTime DELETE MIDSERVER: Midserver $midserverName not found, Cannot delete"	
		Write-Output "$logTime Midserver $midserverName not found, Cannot delete"	
		$global:midStatus = $false
	}
	else
	{
		Add-Content $myLog "$logTime DELETE MIDSERVER: Midserver $midserverName found in folder $folder"	
		Write-Output "$logTime Midserver $midserverName found in folder $folder"	
	}
}

# ------------------------------------------------
# Check that Midserver folder and config.xml exist
# ------------------------------------------------
if ( $global:midStatus -eq $true )
{
	If ( !(test-path $configFile) )
	{
		Add-Content $myLog "$logTime DELETE MIDSERVER: Delete failed, $configFile does not exist"
		$global:midStatus = $false	
		exit 0
	}
}

# --------------------------------------------
# - Delete Midserver
# --------------------------------------------
if ( $global:midStatus -eq $true )
{
	$deleteFolder  = $midRoot + "\" + $folder
	$binFolder     = $midRoot + "\" + $folder + '\agent\bin\'
	$binInstallBat = $binFolder + 'UnInstallMID-NT.bat'
	Add-Content $myLog "$logTime DELETE MIDSERVER: UnInstallMID-NT.bat"
	$output = cmd.exe /c $binInstallBat                           
	Add-Content $myLog "$logTime DELETE MIDSERVER: $output"
	Write-Output $output
	
	Remove-Item $deleteFolder -Force -Recurse	
	Add-Content $myLog "$logTime DELETE MIDSERVER: $deleteFolder deleted"
	Write-Output "$deleteFolder deleted"
}
