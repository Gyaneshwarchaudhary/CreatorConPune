# =============================================================================================================
#  Download Midserver from ServiceNow to tools folder and unzip it to outdir folder 
#  Parameters:
#     - ourDir      : mid folder name or mid.xml in tools directory
#     - url         : full http://....zip to download Midserver zip package
#     - version     : ServiceNow version (helsinki, kingston,...)
#     - download    : download or use already downloaded zip, default = true ( = download), false = only unzip from tools to outDir folder
#  Usage:
#     - Example: .\DownloadMidServer.ps1 myMidserverFolder -version kingston (= default)
#     - Example: .\DownloadMidServer.ps1 mid.xml  (= look the output foldername in tools\mid.xml )
#     - Example: .\DownloadMidServer.ps1 mid.xml "https://install.service-now.com/glide/distribution/builds/package/mid/2017/09/12/mid.helsinki-03-16-2016__patch12a-08-25-2017_09-12-2017_1404.windows.x86-64.zip"
# =============================================================================================================
Param(
  [Parameter(Mandatory=$true)]
  [string]$outDir
 ,[Parameter(Mandatory=$false)]
  [string]$version = "kingston"  
 ,[Parameter(Mandatory=$false)]
  [string]$url
 ,[Parameter(Mandatory=$false)]
  [bool]$download = $true  
)
#G:\ServiceNow\tools\defs.ps1
[string]$midRoot  = "G:\ServiceNow\";
[string]$midTools = $midRoot + "tools\"
[string]$myLog    = $midTools + "install.log"
[string]$host     = hostname
$logTime = Get-Date -Format "yyyy-MM-dd hh:mm:ss"


# -------------------------------------------------
# check if $outdir is xml file where we find folder
# -------------------------------------------------
$xmlFile = ""
$xmlSuffix = $outDir.split('.')[-1]
if ( $xmlSuffix -eq "xml" )
{
	$xmlFile = $midTools + "\" + $outDir
}
If ( $xmlFile -ne "" )
{
	If ( test-path $xmlFile )
	{
		[xml]$XmlDocument = Get-Content -Path $xmlFile
		foreach ( $par in $XmlDocument.Parameters.Parameter )
		{
			$key = $par.name
			$val = $par.value
			if ( $key -eq "folder" )   
			{ 
				$outDir = $val 
			}
		}
	}
}
# full path name of unzip folder
$fullOutDir = $midRoot + $outDir
Add-Content $myLog "$logTime Download url $url"

# we give here the default for MIdserver url
If ( $url -eq "" )
{
	if ( $version -eq "kingston" )
	{
		# current default for Kingston
		$url = "https://install.service-now.com/glide/distribution/builds/package/mid/2018/01/03/mid.kingston-10-17-2017__patch1-12-12-2017_01-03-2018_0843.windows.x86-64.zip"
	}
	else
	{
		# current default for others
		$url = "https://install.service-now.com/glide/distribution/builds/package/mid/2017/09/12/mid.helsinki-03-16-2016__patch12a-08-25-2017_09-12-2017_1404.windows.x86-64.zip"
	}
}

$zipFile = $url.split('/')[-1]
$suffixFile = $zipFile.split('.')[-1]
$zipFullName = $midTools + $zipFile

# ----------------------------------------------------------------------------------------------
# --- M A I N 
# ----------------------------------------------------------------------------------------------

$logTime = Get-Date -Format "yyyy-MM-dd hh:mm:ss"
Add-Content $myLog "$logTime Download version $version"
Add-Content $myLog "$logTime Download url $url"
Add-Content $myLog "$logTime Starting download Midserver $zipFile to $outDir"

# --------------------------
# Download the Midserver zip
# --------------------------
$Client = New-Object -TypeName System.Net.WebClient
$proxy = New-Object -TypeName System.Net.WebProxy
# Proxy url
$proxy.Address = "http://web-gw1.rowini.net:8080"
$proxy.Credentials = (new-object System.Net.NetworkCredential("", "", ""))
$Client.Proxy = $proxy
$LASTEXITCODE = 1
# Download requested
if ( $download -eq $true )
{
	# if exactly same patch zip is already downloaded, no need to download again
	If ( test-path $zipFullName )
	{
		Add-Content $myLog "$logTime Midserver zip is already available, no need to download"
	}
	else
	{
		# Download 
		$Client.DownloadFile($url, $zipFullName)
	}
}
if ( $LASTEXITCODE -ne 1 )
{
	Write-Output "Midserver downloaded failed to $fullOutDir"
	Add-Content $myLog "$logTime Midserver downloaded failed to $fullOutDir, exit code $LASTEXITCODE"
	$global:midStatus = $false	
	exit 0			
}

# ----------------------------------
# unzip file to new Midserver folder
# ----------------------------------
$logTime = Get-Date -Format "yyyy-MM-dd hh:mm:ss"
if ( $suffixFile -eq "zip" )
{
	If ( !(test-path $fullOutDir) )
	{
		[System.Reflection.Assembly]::LoadWithPartialName('System.IO.Compression.FileSystem')
		[System.IO.Compression.ZipFile]::ExtractToDirectory($zipFullName, $fullOutDir)
		$cfg = $fullOutDir + "\agent\config.xml"
		If ( Test-Path $cfg )
		{
			Write-Output "Midserver downloaded successfully to $fullOutDir"
			Add-Content $myLog "$logTime Midserver downloaded successfully to $fullOutDir"
		}
		else
		{
			Write-Output "Midserver downloaded failed to $fullOutDir"
			Add-Content $myLog "$logTime Midserver downloaded failed to $fullOutDir"
			$global:midStatus = $false
			exit 0
		}
	}
	else
	{
		Write-Output "Outdir already exists. Midserver downloaded failed to $fullOutDir"
		Add-Content $myLog "$logTime Outdir already exists. Midserver downloaded failed to $fullOutDir"
		$global:midStatus = $false		
		exit 0
	}
}
else
{
		Write-Output "Not zip file. Midserver downloaded failed to $fullOutDir"
		Add-Content $myLog "$logTime Not zip file. Midserver downloaded failed to $fullOutDir"
		$global:midStatus = $false		
		exit 0		
}
exit 1
