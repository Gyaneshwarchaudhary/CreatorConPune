# =============================================================================================================
#  Configure config.xml of the new Midserver
#  Parameters:
#      - folder
#      - instance
#      - user
#      - password
#      - instance name
#  Usage:
#  - Example: .\configureMidConfigXml.ps1 mymidfolder tempinstance mid.server.tempuser mid.server.temppw "Midserver TempXXX"
# =============================================================================================================
Param(
  [Parameter(Mandatory=$true)]
  [string]$folder
 ,[Parameter(Mandatory=$true)]
  [string]$instance
 ,[Parameter(Mandatory=$true)]
  [string]$user
 ,[Parameter(Mandatory=$true)]
  [string]$pw
 ,[Parameter(Mandatory=$true)]
  [string]$name
)
#G:\ServiceNow\tools\defs.ps1
[string]$midRoot  = "G:\ServiceNow\";
[string]$midTools = $midRoot + "tools\"
[string]$myLog    = $midTools + "install.log"
[string]$host     = hostname
$logTime = Get-Date -Format "yyyy-MM-dd hh:mm:ss"


$logTime = Get-Date -Format "yyyy-MM-dd hh:mm:ss"

$outPath = ""
$lineURL        = '       <parameter name="url" value="https://YOUR_INSTANCE.service-now.com"/>'
$lineUSER       = '       <parameter name="mid.instance.username" value="YOUR_INSTANCE_USER_NAME_HERE" />'
$linePASSW      = '       <parameter name="mid.instance.password" value="YOUR_INSTANCE_PASSWORD_HERE"/>'
$lineNAME       = '       <parameter name="name" value="YOUR_MIDSERVER_NAME_GOES_HERE"/>'
$linePROXYHOST  = '       <parameter name="mid.proxy.host" value="web-gw1.rowini.net"/>'
$linePROXYPORT  = '       <parameter name="mid.proxy.port" value="8080"/>'
$lineGLIDEHOST  = '       <parameter name="glide.mid.autoupgrade.proxy_host"     value="web-gw1.rowini.net"     />'
$lineGLIDEPORT  = '       <parameter name="glide.mid.autoupgrade.proxy_port"     value="8080"     />'
$lineURL   = $lineURL   -replace "YOUR_INSTANCE"                , $instance
$lineUSER  = $lineUSER  -replace "YOUR_INSTANCE_USER_NAME_HERE" , $user
$linePASSW = $linePASSW -replace "YOUR_INSTANCE_PASSWORD_HERE"  , $pw
$lineNAME  = $lineNAME  -replace "YOUR_MIDSERVER_NAME_GOES_HERE", $name

Function ReadFile {
    Param(
    [string]$file
    )
    Process
    {
        $read = New-Object System.IO.StreamReader($file)
        $serverarray = @()

        while ( ($line = $read.ReadLine()) -ne $null )
        {
            $serverarray += $line
        }

        $read.Dispose()
        return $serverarray
    }
}

Function AddLine {
    Param(
    [string]$line
    )
	if ( $inComment -eq 1 )
	{
		"       -->" | Add-Content -Path $outPath					
	}
	$line | Add-Content -Path $outPath		
	if ( $inComment -eq 1 )
	{
		"       <!--" | Add-Content -Path $outPath					
	}	
}

# ----------------------------------------------------------------------------------------------
# --- M A I N 
# ----------------------------------------------------------------------------------------------

$fullOutDir = $midRoot + $folder
$configFile = $fullOutDir + "\agent\config.xml"
Add-Content $myLog "$logTime Configuring $configFile"
Add-Content $myLog "$logTime - folder    $folder"
Add-Content $myLog "$logTime - instance  $instance"
Add-Content $myLog "$logTime - user      $user"
Add-Content $myLog "$logTime - pw        $pw"
Add-Content $myLog "$logTime - name      $name"



If ( !(test-path $configFile) )
{
	Add-Content $myLog "$logTime Configuration failed, $configFile does not exist"
	$global:midStatus = $false		
	exit 0
}
$lines = Get-Content $configFile

$outPath = $fullOutDir + '\agent\config.xml'
Clear-Content $outPath
[int]$inComment = 0
foreach ( $line in $lines )
{
 	if ( $line -like "*<!--*" )
	{
		$inComment = 1
	}
	if ( $line -like "*-->*" )
	{
		$inComment = 0
	}
	if ( $line -like "*parameter name*" -and $line -like "*url*" )
	{
		$line = $lineURL
	}
	if ( $line -like "*parameter name*" -and $line -like "*instance.username*" )
	{
		$line = $lineUSER
	}
	if ( $line -like "*parameter*"      -and $line -like "*instance.password*" )
	{
		$line = $linePASSW
	}
	if ( $line -like "*parameter name*" -and $line -like '*name="name"*' )
	{
		$line = $lineNAME
	}
	if ( $line -like "*parameter name*" -and $line -like "*mid.proxy.use_proxy*" )
	{
		AddLine -line $line
	}
	if ( $line -like "*parameter name*" -and $line -like "*mid.proxy.host*" )
	{
		AddLine -line $linePROXYHOST
	}
	if ( $line -like "*parameter name*" -and $line -like "*mid.proxy.port*" )
	{
		AddLine -line $linePROXYPORT
	}
	if ( $line -like "*parameter name*" -and $line -like "*glide.mid.autoupgrade.proxy_host*" )
	{
		AddLine -line $lineGLIDEHOST
	}
	if ( $line -like "*parameter name*" -and $line -like "*glide.mid.autoupgrade.proxy_port*" )
	{
		AddLine -line $lineGLIDEPORT
	}	
	$line | Add-Content -Path $outPath		
}
$logTime = Get-Date -Format "yyyy-MM-dd hh:mm:ss"
Write-Output $myLog "$logTime $outPath configured"
Add-Content $myLog "$logTime $outPath configured"
