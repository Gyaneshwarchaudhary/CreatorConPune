# =============================================================================================================
#  Read config params from existing Midserver to mid.xml in tools folder
#  Parameters:
#       - midserverName   : Name of existing Midserver name on SNOW side (example: MID Server SBX1_1)
#       - outXml          : output to mid.xml  in tools folder
#  Usage:
#  - Example: .\createConfigXml.ps1 "MID Server SBX1_5" temp.xml
# =============================================================================================================
Param(
  [Parameter(Mandatory=$true)]
  [string]$midserverName
 ,[Parameter(Mandatory=$true)]
  [string]$outXml
)
#G:\ServiceNow\tools\defs.ps1
[string]$midRoot  = "G:\ServiceNow\";
[string]$midTools = $midRoot + "tools\"
[string]$myLog    = $midTools + "install.log"
[string]$host     = hostname
$logTime = Get-Date -Format "yyyy-MM-dd hh:mm:ss"


$folder = $midName
[string]$allMids = $midTools + "allMids.txt"
$logTime = Get-Date -Format "yyyy-MM-dd hh:mm:ss"

[string]$configFile = $midRoot + $folder + "\agent\config.xml"
[string]$overrideFile = $midRoot + $folder + "\agent\conf\wrapper-override.conf"

Add-Content $myLog "$logTime Reading params from Midserver $midserverName"

# ----------------------------------------------------
# Get and save all midserver names to avoid duplicates
# ----------------------------------------------------
If ( test-path $allMids )
{
	Clear-Content $allMids
}

# Search folder name from midname in SNOW
[bool]$midFound = $false
$lines = Get-ChildItem 'G:\ServiceNow\*\config.xml' -recurse | Select-String -Pattern 'name="name"'
foreach ( $line in $lines )
{
	[string]$li = [string]$line;
	[string]$str1 = $li.split('=')[2]
	[string]$midName = $str1.split('"')[1]
	if ( ! ($li -like "*archive*" ) )
	{
    	Add-Content $allMids $midName
	}
	
	if ( ! ($li -like "*archive*" ) -and $li -like "*$midserverName*"  )
	{
		If ( ! (test-path $configFile) )
		{
			$folder  = [string]$li.split("\")[2]
			$configFile = $midRoot + $folder + "\agent\config.xml"
			$overrideFile = $midRoot + $folder + "\agent\conf\wrapper-override.conf"
			$midFound = $true
		}
	}
}
if ( $midFound -eq $false )
{
	Add-Content $myLog "$logTime Midserver $midserverName not found, installation failed"	
	Write-Output "$logTime Midserver $midserverName not found, installation failed"	
	$global:midStatus = $false
	exit 0
}

# ----------------------------------------------------------------------------------------------
# --- M A I N 
# ----------------------------------------------------------------------------------------------

If ( !(test-path $configFile) )
{
	Add-Content $myLog "$logTime Configuration failed, $configFile does not exist"
	$global:midStatus = $false	
	exit 0
}

# Make output xml empty
$fullNameXml = $midTools + '\' + $outXml;
If ( test-path $fullNameXml )
{
	Clear-Content $fullNameXml
}

# Write XML "headers"
'<?xml version="1.0" encoding="UTF-8"?>' | Add-Content -Path $fullNameXml		
"<parameters>" | Add-Content -Path $fullNameXml		
$str = '       <parameter name="folder"     value="' + $folder + '" />'
$str | Add-Content -Path $fullNameXml		

# -------------------------
# Write config.xml XML data
# -------------------------
Add-Content $myLog "$logTime Reading params from $configFile "
$lines = Get-Content $configFile
foreach ( $line in $lines )
{
	if ( $line -like "*parameter name*" -and $line -like "*url*" )
	{
		[string]$str1 = $line.split(':')[1]
		[string]$str2 = $str1.split('.')[0]
		$str2 = $str2 -replace '//',''
		[string]$str3 = '       <parameter name="instance"   value="' + $str2 + '" />'
        $str3 | Add-Content -Path $fullNameXml		
	}
	if ( $line -like "*parameter name*" -and $line -like "*instance.username*" )
	{
		[string]$str1 = $line.split('=')[2]
		[string]$str2 = $str1.split('"')[1]
		[string]$str3 = '       <parameter name="user"       value="' + $str2 + '" />'
        $str3 | Add-Content -Path $fullNameXml		
	}
	if ( $line -like "*parameter name*" -and $line -like "*instance.password*" )
	{
		[string]$str1 = $line.split('=')[2]
		[string]$str2 = $str1.split('"')[1]
		[string]$str3 = '       <parameter name="pw"         value="' + $str2 + '" />'
        $str3 | Add-Content -Path $fullNameXml		
	}
	if ( $line -like "*parameter name*" -and $line -like '*name="name"*' )
	{
		[string]$str1 = $line.split('=')[2]
		[string]$str2 = $str1.split('"')[1]
		[string]$str3 = '       <parameter name="name"       value="' + $str2 + '" />'
        $str3 | Add-Content -Path $fullNameXml		
	}
}

# --------
# Override
# --------
If ( !(test-path $overrideFile) )
{
	Add-Content $myLog "$logTime Configuration failed, $overrideFile does not exist"
	$global:midStatus = $false	
	exit 0
}
Add-Content $myLog "$logTime Reading params from $overrideFile"
$lines = Get-Content $overrideFile
foreach ( $line in $lines )
{
	if ( $line -like "*wrapper.name*" )
	{
		[string]$str1 = $line.split('=')[1]
		[string]$str2 = '       <parameter name="service"    value="' + $str1 + '" />'
        $str2 | Add-Content -Path $fullNameXml		
	}
	if ( $line -like "*wrapper.displayname*" )
	{
		[string]$str1 = $line.split('=')[1]
		[string]$str2 = '       <parameter name="display"    value="' + $str1 + '" />'
        $str2 | Add-Content -Path $fullNameXml		
	}
	if ( $line -like "*javaagent*" -and !($line -like "#*")  )
	{
		$line = $line -replace '"',''''
		[string]$str1 = '       <parameter name="javaAgent"  value="' + $line + '" />'
        $str1 | Add-Content -Path $fullNameXml		
	}
	if ( $line -like "*applicationName*" -and !($line -like "#*")  )
	{
		[string]$str1 = '       <parameter name="appName"    value="' + $line + '" />'
        $str1 | Add-Content -Path $fullNameXml		
	}
	if ( $line -like "*tierName*" -and !($line -like "#*")  )
	{
		[string]$str1 = '       <parameter name="tierName"   value="' + $line + '" />'
        $str1 | Add-Content -Path $fullNameXml		
	}
	if ( $line -like "*nodeName*" -and !($line -like "#*")  )
	{
		$line = $line -replace '"',''''
		[string]$str1 = '       <parameter name="nodeName"   value="' + $line + '" />'
        $str1 | Add-Content -Path $fullNameXml		
	}	
}
# Write XML "footer"
"</parameters>" | Add-Content -Path $fullNameXml		

# Write result to install log
$lines = Get-Content $fullNameXml
foreach ( $line in $lines )
{
	Add-Content $myLog "$logTime $line"
}

$logTime = Get-Date -Format "yyyy-MM-dd hh:mm:ss"
Add-Content $myLog "$logTime params read into $fullNameXml "

exit 1