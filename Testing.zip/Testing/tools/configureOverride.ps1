# =============================================================================================================
#  Configure wrapper-override.conf of the new Midserver
#  Parameters:
#      - folder
#      - service name
#      - service display name
#      - service console name
#      - AppDynamics javaAgent
#      - AppDynamics applicationName
#      - AppDynamics tierName
#      - AppDynamics nodeName
#  Usage:
#  - Example: .\configureMidOverride.ps1 VesaTest snc_tempx "Service-now MID Server TestX" "Service-now MID Server TestX"
# =============================================================================================================
Param(
  [Parameter(Mandatory=$true)]
  [string]$folder
 ,[Parameter(Mandatory=$true)]
  [string]$service
 ,[Parameter(Mandatory=$true)]
  [string]$display
 ,[Parameter(Mandatory=$true)]
  [string]$console
 ,[Parameter(Mandatory=$true)]
  [string]$javaAgent
 ,[Parameter(Mandatory=$true)]
  [string]$appName
 ,[Parameter(Mandatory=$true)]
  [string]$tierName
 ,[Parameter(Mandatory=$true)]
  [string]$nodeName
)
#G:\ServiceNow\tools\defs.ps1
[string]$midRoot  = "G:\ServiceNow\";
[string]$midTools = $midRoot + "tools\"
[string]$myLog    = $midTools + "install.log"
[string]$host     = hostname
$logTime = Get-Date -Format "yyyy-MM-dd hh:mm:ss"


$logTime = Get-Date -Format "yyyy-MM-dd hh:mm:ss"

$lineSERVICE = "wrapper.name=" + $service 
$lineDISPLAY = 'wrapper.displayname=' + $display
$lineCONSOLE = 'wrapper.console.title=' + $console
$lineMEMORY  = 'wrapper.java.maxmemory=1024'
$linePING    = 'wrapper.ping.timeout=300'
$lineSTARTUP = 'wrapper.startup.timeout=60'

# ----------------------------------------------------------------------------------------------
# --- M A I N 
# ----------------------------------------------------------------------------------------------

$fullOutDir = $midRoot + $folder
$overrideFile = $fullOutDir + "\agent\conf\wrapper-override.conf"
Write-Output "Configuring $overrideFile"
Add-Content $myLog "$logTime Configuring $overrideFile"
Add-Content $myLog "$logTime - folder    $folder"
Add-Content $myLog "$logTime - service   $service"
Add-Content $myLog "$logTime - display   $display"
Add-Content $myLog "$logTime - console   $console"
Add-Content $myLog "$logTime - javaAgent $javaAgent"
Add-Content $myLog "$logTime - appName   $appName"
Add-Content $myLog "$logTime - tierName  $tierName"
Add-Content $myLog "$logTime - nodeName  $nodeName"

If ( !(test-path $overrideFile) )
{
	Add-Content $myLog "$logTime Configuration failed, $overrideFile does not exist"
	$global:midStatus = $false		
    exit 0	
}
$lines = Get-Content $overrideFile
$outPath = $overrideFile
Clear-Content $outPath
foreach ( $line in $lines )
{
	if ( $line -like "*wrapper.name*" )
	{
		$line = $lineSERVICE
	}
	if ( $line -like "*wrapper.displayname*" )
	{
		$line = $lineDISPLAY
	}
	if ( $line -like "*wrapper.console.title*" )
	{
		$line = "#"
	}
	if ( $line -like "*wrapper.java.maxmemory*" )
	{
		$line = "#"
	}
	if ( $line -like "*wrapper.ping.timeout*" )
	{
		$line = "#"
	}
	if ( $line -like "*wrapper.startup.timeout*" )
	{
		$line = "#"
	}
	$line | Add-Content -Path $outPath		
}
$lineMEMORY  | Add-Content -Path $outPath		
$linePING    | Add-Content -Path $outPath		
$lineSTARTUP | Add-Content -Path $outPath		
$lineCONSOLE | Add-Content -Path $outPath		

$javaAgent = $javaAgent -replace '''', '"'
$nodeName  = $nodeName  -replace '''', '"'

$javaAgent   | Add-Content -Path $outPath		
$appName     | Add-Content -Path $outPath		
$tierName    | Add-Content -Path $outPath		
$nodeName    | Add-Content -Path $outPath		

$logTime = Get-Date -Format "yyyy-MM-dd hh:mm:ss"
Add-Content $myLog "$logTime $outPath configured"

exit 1
