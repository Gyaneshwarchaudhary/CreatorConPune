[string]$midRoot  = "G:\ServiceNow\";
[string]$midTools = $midRoot + "tools\"
[string]$myLog    = $midTools + "install.log"
[string]$host     = hostname
$logTime = Get-Date -Format "yyyy-MM-dd hh:mm:ss"

