# =============================================================================================================
# = Read mid.xml from tools folder and modify the Midserver parameters to make them unique
# = Parameters:
# = - xmlIn    : input xml
# = - xmlOut   : output xml
# = Usage:
# = - Example: .\adjustConfigXml.ps1  temp.xml mid.xml
# =============================================================================================================
Param(
  [Parameter(Mandatory=$true)]
  [string]$xmlIn
 ,[Parameter(Mandatory=$true)]
  [string]$xmlOut
)
#G:\ServiceNow\tools\defs.ps1
[string]$midRoot  = "G:\ServiceNow\";
[string]$midTools = $midRoot + "tools\"
[string]$myLog    = $midTools + "install.log"
[string]$host     = hostname
$logTime = Get-Date -Format "yyyy-MM-dd hh:mm:ss"


$logTime = Get-Date -Format "yyyy-MM-dd hh:mm:ss"
Add-Content $myLog "$logTime Writing $xmlIn to $xmlOut"

[string]$fullXmlIn  = $midTools + "\" + $xmlIn
[string]$fullXmlOut = $midTools + "\" + $xmlOut

# -----------------------------------------
# function to replace latest part of string
# -----------------------------------------
function Replace-LastSubstring {
    param(
        [string]$str,
        [string]$substr,
        [string]$newstr
    )
    return $str.Remove(($lastIndex = $str.LastIndexOf($substr)),$substr.Length).Insert($lastIndex,$newstr)
}

# ------------------------------------------------------------------------------------------------
# Add hostname identifier (98/81/82/....) to string
# ------------------------------------------------------------------------------------------------
Function addShortHost([string]$strIn)
{
	[string]$host      = hostname
	[string]$shortHost = $host.Substring($host.Length - 2, 2);
	$shortHost = "_" + $shortHost
	$idx = $strIn.LastIndexOf($shortHost) 
	# hostid not found, add it
	if ( $idx -eq -1 )	
	{
		# string ends with digits, add hostid before them
		if ( $strIn -match ".([0-9]$)" )
		{
			[string]$nbr = [string]$Matches[0]
			$nbr = $nbr -replace "_",""
			$nbr = $nbr -replace "[a-z]",""
			$nbr = $nbr -replace "[A-Z]",""
			$newSuffix = $shortHost + "_" + $nbr	
			$strIn = Replace-LastSubstring "$strIn" "$nbr" "$newSuffix"	
			$strIn = $strIn -replace "__","_"
		}
		# string does not end with digits, add suffix "_1"
		else
		{
			$strIn = $strIn + $shortHost + "_1"
		}
	}
	return $strIn
}

# ------------------------------------------------------------------------------------------------
# Find the last digits in string and replace them with global:midNnr
# ------------------------------------------------------------------------------------------------
Function changeSuffixNumber([string]$strIn)
{
	if ( $strIn -match ".([0-9]$)" )
	{
		[string]$nbr = [string]$Matches[0]
		$nbr = $nbr -replace "_",""
		$nbr = $nbr -replace "[a-z]",""
		$nbr = $nbr -replace "[A-Z]",""
		$strIn = Replace-LastSubstring "$strIn" "$nbr" "$global:midNnr"
	}
	return $strIn
}

# ------------------------------------------------------------------------------------------------
# function to modify last digits of the string by adding one (if digit available, start with "_0")
# It also check that modified name is unique
# example: MID Server SBX1_1  ---> MID Server SBX1_2
# ------------------------------------------------------------------------------------------------
Function adjustName([string]$name, [string]$strIn)
{
	[string]$strOut = [string]$strIn
	[int]$i = $global:midNnr - 1
	#Add-Content $myLog "$logTime Adjust IN : MIDNBR : $global:midNnr : $i"	
	while ( $i -lt 100 )
	{
		if ( $strIn -match ".([0-9]$)" )
		{
			[string]$nbr = [string]$Matches[0]
			$nbr = $nbr -replace "_",""
			$nbr = $nbr -replace "[a-z]",""
			$nbr = $nbr -replace "[A-Z]",""
			[int]$nbrInt = [int]$nbr + $i
			[string]$nbrString = [string]$nbrInt
			$strOut = Replace-LastSubstring "$strIn" "$nbr" "$nbrString"
			$global:midNnr = $nbrInt
			$i = $i + 1
		}
		else
		{
			$i = $i + 1
			$strOut = $strIn + "_" + [string]$i
			$global:midNnr = $i
		}
		#Add-Content $myLog "$logTime Adjust : $name : $strOut"		
		if ( !($midTbl.ContainsKey($strOut)) )
		{
			Add-Content $myLog "$logTime Adjust : $name : $strOut BREAK"	
			break
		}
	}
	#Add-Content $myLog "$logTime Adjust OUT : MIDNBR : $global:midNnr : $i"	
	
	return $strOut
}

# ----------------------------------------------------------------------------------------------
# --- M A I N 
# ----------------------------------------------------------------------------------------------

[string]$folder = ""
[string]$instance = ""
[string]$user = ""
[string]$pw = ""
[string]$name = ""
[string]$service = ""
[string]$display = ""
[string]$javaAgent = ""
[string]$appName = ""
[string]$tierName = ""
[string]$nodeName = ""

$midTbl = @{}

Add-Content $myLog "$logTime configuring $fullXmlOut"

# --------------------------------------------
# - parse XML parameters
# --------------------------------------------
If ( !(test-path $fullXmlIn) )
{
	Add-Content $myLog "$logTime Configuration failed, $configFile does not exist"
	$global:midStatus = $false	
	exit 0
}
[xml]$XmlDocument = Get-Content -Path $fullXmlIn
foreach ( $par in $XmlDocument.Parameters.Parameter )
{
    $key = $par.name
    $val = $par.value
    if ( $key -eq "folder" )     { $folder    = $val }
    if ( $key -eq "instance" )   { $instance  = $val }
    if ( $key -eq "user" )       { $user      = $val }
    if ( $key -eq "pw" )         { $pw        = $val }
    if ( $key -eq "name" )       { $name      = $val }
    if ( $key -eq "service" )    { $service   = $val }
    if ( $key -eq "display" )    { $display   = $val }	
    if ( $key -eq "javaAgent" )  { $javaAgent = $val }
    if ( $key -eq "appName" )    { $appName   = $val }
    if ( $key -eq "tierName" )   { $tierName  = $val }
    if ( $key -eq "nodeName" )   { $nodeName  = $val }
}

$lines = Get-Content "G:\ServiceNow\tools\allMids.txt"
foreach ( $line in $lines )
{
	if ( !($midTbl.ContainsKey($line)) )
	{
		$midTbl.Add($line, " ")
	}
}

# --------------------------------------------
# - Adjust some parameters (= make unique)
# --------------------------------------------

# add host to name
$name = addShortHost $name
$folder = addShortHost $folder
$service = addShortHost $service
$display = addShortHost $display

# make names unique
$global:midNnr = 1
$name    = adjustName "name"    "$name"

$folder  = changeSuffixNumber "$folder"
$service = changeSuffixNumber "$service"
$display = changeSuffixNumber "$display"

# make double quotes single
if ( $nodeName -match ".'$" )
{
	Add-Content $myLog "$logTime ADJUST: $nodeName ends with quote"
	$nodeName = $nodeName.Remove($nodeName.LastIndexOf("'"), 1)
	$nodeName = addShortHost $nodeName
    $nodeName = changeSuffixNumber "$nodeName"
	$nodeName = $nodeName + "'"
}

# --------------------------------------------
# - Write adjusted mid.xml
# --------------------------------------------
If ( test-path $fullXmlOut )
{
	Clear-Content $fullXmlOut
}
'<?xml version="1.0" encoding="UTF-8"?>' | Add-Content -Path $fullXmlOut
"<parameters>" | Add-Content -Path $fullXmlOut
[string]$str = '       <parameter name="folder"     value="' + $folder + '" />'
$str | Add-Content -Path $fullXmlOut
$str = '       <parameter name="instance"   value="' + $instance + '" />'
$str | Add-Content -Path $fullXmlOut	
$str = '       <parameter name="user"       value="' + $user + '" />'
$str | Add-Content -Path $fullXmlOut	
$str = '       <parameter name="pw"         value="' + $pw + '" />'
$str | Add-Content -Path $fullXmlOut	
$str = '       <parameter name="name"       value="' + $name + '" />'
$str | Add-Content -Path $fullXmlOut	
$str = '       <parameter name="service"    value="' + $service + '" />'
$str | Add-Content -Path $fullXmlOut	
$str = '       <parameter name="display"    value="' + $display + '" />'
$str | Add-Content -Path $fullXmlOut	
$str = '       <parameter name="javaAgent"  value="' + $javaAgent + '" />'
$str | Add-Content -Path $fullXmlOut	
$str = '       <parameter name="appName"    value="' + $appName + '" />'
$str | Add-Content -Path $fullXmlOut	
$str = '       <parameter name="tierName"   value="' + $tierName + '" />'
$str | Add-Content -Path $fullXmlOut	
$str = '       <parameter name="nodeName"   value="' + $nodeName + '" />'
$str | Add-Content -Path $fullXmlOut	

"</parameters>" | Add-Content -Path $fullXmlOut		

$lines = Get-Content $fullXmlOut		
foreach ( $line in $lines )
{
	Add-Content $myLog "$logTime $line"
}

$logTime = Get-Date -Format "yyyy-MM-dd hh:mm:ss"
Add-Content $myLog "$logTime $fullXmlOut created"

exit 1