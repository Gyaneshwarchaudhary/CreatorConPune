# =============================================================================================================
# = Read mid.xml from tools folder and modify the Midserver parameters to make them unique
# = Parameters:
# = - xmlFile     : input/output mid.xml
# = - newInstance : new istance name
# = Usage:
# = - Example: .\adjustNewInstance.ps1 temp.xml cssnowsand9
# =============================================================================================================
Param(
  [Parameter(Mandatory=$true)]
  [string]$xmlFile
 ,[Parameter(Mandatory=$true)]
  [string]$newInstance
)
#G:\ServiceNow\tools\defs.ps1
[string]$midRoot  = "G:\ServiceNow\";
[string]$midTools = $midRoot + "tools\"
[string]$myLog    = $midTools + "install.log"
[string]$host     = hostname
$logTime = Get-Date -Format "yyyy-MM-dd hh:mm:ss"


$logTime = Get-Date -Format "yyyy-MM-dd hh:mm:ss"
Add-Content $myLog "$logTime With new instance name modifying $xmlFile"
[string]$fullXmlFile = $midTools + "\" + $xmlFile

# ----------------------------------------------------------------------------------------------
# --- M A I N 
# ----------------------------------------------------------------------------------------------

[string]$folder = ""
[string]$instance = ""
[string]$user = ""
[string]$pw = ""
[string]$name = ""
[string]$service = ""
[string]$display = ""
[string]$javaAgent = ""
[string]$appName = ""
[string]$tierName = ""
[string]$nodeName = ""

# --------------------------------------------
# - parse XML parameters
# --------------------------------------------
If ( !(test-path $fullXmlFile) )
{
	Add-Content $myLog "$logTime Configuration failed, $configFile does not exist"
	$global:midStatus = $false	
	exit 0
}
[xml]$XmlDocument = Get-Content -Path $fullXmlFile
foreach ( $par in $XmlDocument.Parameters.Parameter )
{
    $key = $par.name
    $val = $par.value
    if ( $key -eq "folder" )     { $folder    = $val }
    if ( $key -eq "instance" )   { $instance  = $val }
    if ( $key -eq "user" )       { $user      = $val }
    if ( $key -eq "pw" )         { $pw        = $val }
    if ( $key -eq "name" )       { $name      = $val }
    if ( $key -eq "service" )    { $service   = $val }
    if ( $key -eq "display" )    { $display   = $val }	
    if ( $key -eq "javaAgent" )  { $javaAgent = $val }
    if ( $key -eq "appName" )    { $appName   = $val }
    if ( $key -eq "tierName" )   { $tierName  = $val }
    if ( $key -eq "nodeName" )   { $nodeName  = $val }
}

# Something wrong with xml, it's better to stop
if ( $folder -eq "" )
{
	Add-Content $myLog "$logTime Configuration failed, $configFile has XML syntax errors"
	$global:midStatus = $false	
	exit 0
}

# --------------------------------------------
# - Adjust some parameters
# --------------------------------------------

$folder   = $newInstance
$instance = $newInstance
$name     = $newInstance
$service  = "snc_agent_" + $newInstance
$display  = "Service-now MID Server_" + $newInstance
$nodeName = "wrapper.java.additional.6=-Dappdynamics.agent.nodeName='Service-now MID Server_" + $newInstance + "'"

# --------------------------------------------
# - Write adjusted mid.xml
# --------------------------------------------
If ( test-path $fullXmlFile )
{
	Clear-Content $fullXmlFile
}
'<?xml version="1.0" encoding="UTF-8"?>' | Add-Content -Path $fullXmlFile
"<parameters>" | Add-Content -Path $fullXmlFile
[string]$str = '       <parameter name="folder"     value="' + $folder + '" />'
$str | Add-Content -Path $fullXmlFile
$str = '       <parameter name="instance"   value="' + $instance + '" />'
$str | Add-Content -Path $fullXmlFile	
$str = '       <parameter name="user"       value="' + $user + '" />'
$str | Add-Content -Path $fullXmlFile	
$str = '       <parameter name="pw"         value="' + $pw + '" />'
$str | Add-Content -Path $fullXmlFile	
$str = '       <parameter name="name"       value="' + $name + '" />'
$str | Add-Content -Path $fullXmlFile	
$str = '       <parameter name="service"    value="' + $service + '" />'
$str | Add-Content -Path $fullXmlFile	
$str = '       <parameter name="display"    value="' + $display + '" />'
$str | Add-Content -Path $fullXmlFile	
$str = '       <parameter name="javaAgent"  value="' + $javaAgent + '" />'
$str | Add-Content -Path $fullXmlFile	
$str = '       <parameter name="appName"    value="' + $appName + '" />'
$str | Add-Content -Path $fullXmlFile	
$str = '       <parameter name="tierName"   value="' + $tierName + '" />'
$str | Add-Content -Path $fullXmlFile	
$str = '       <parameter name="nodeName"   value="' + $nodeName + '" />'
$str | Add-Content -Path $fullXmlFile	

"</parameters>" | Add-Content -Path $fullXmlFile		

$lines = Get-Content $fullXmlFile		
foreach ( $line in $lines )
{
	Add-Content $myLog "$logTime $line"
}

$logTime = Get-Date -Format "yyyy-MM-dd hh:mm:ss"
Add-Content $myLog "$logTime $fullXmlFile modified with new instance name $newInstance"

exit 1