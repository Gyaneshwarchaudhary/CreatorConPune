# =============================================================================================================
#  Delete Midserver
#  Parameters:
#       - midserverName   : Name of existing Midserver name on SNOW side (example: MID Server SBX1_98_4)
#       -aczion           : RESTART
#  Usage:
#  - Example: .\midserverAction.ps1 'MID Server SBX1_98_4' RESTART
# =============================================================================================================
Param(
  [Parameter(Mandatory=$true)]
  [string]$midserverName
 ,[Parameter(Mandatory=$true)]
  [string]$action
)
[string]$midRoot  = "G:\ServiceNow\";
[string]$midTools = $midRoot + "tools\"
[string]$myLog    = $midTools + "install.log"
$logTime = Get-Date -Format "yyyy-MM-dd hh:mm:ss"
[bool]$global:midStatus = $true

$folder = ""
[string]$configFile = ""
Add-Content $myLog "$logTime --------------------------------------------------------------------------------------------"
Add-Content $myLog "$logTime ACTION MIDSERVER: CALL PARAM: MidServer $midserverName"

# ---------------------------------------
# Search folder name from midname in SNOW
# ---------------------------------------
if ( $global:midStatus -eq $true )
{
	[bool]$midFound = $false
	$lines = Get-ChildItem 'G:\ServiceNow\*\config.xml' -recurse | Select-String -Pattern 'name="name"'
	foreach ( $line in $lines )
	{
		[string]$li = [string]$line;
		[string]$str1 = $li.split('=')[2]
		[string]$midName = $str1.split('"')[1]
		
		if ( ! ($li -like "*archive*" ) -and $li -like "*$midserverName*"  )
		{
			$folder  = [string]$li.split("\")[2]
			$configFile = $midRoot + $folder + "\agent\config.xml"
			$midFound = $true
		}
	}
	if ( $midFound -eq $false )
	{
		Add-Content $myLog "$logTime ACTION MIDSERVER: Midserver $midserverName not found, Cannot execute"	
		Write-Output "$logTime Midserver $midserverName not found, Cannot execute"	
		$global:midStatus = $false
	}
	else
	{
		Add-Content $myLog "$logTime ACTION MIDSERVER: Midserver $midserverName found in folder $folder"	
		Write-Output "$logTime Midserver $midserverName found in folder $folder"	
	}
}

# ------------------------------------------------
# Check that Midserver folder and config.xml exist
# ------------------------------------------------
if ( $global:midStatus -eq $true )
{
	If ( !(test-path $configFile) )
	{
		Add-Content $myLog "$logTime ACTION MIDSERVER: Execute failed, $configFile does not exist"
		$global:midStatus = $false	
		exit 0
	}
}

# --------------------------------------------
# - Midserver Action
# --------------------------------------------
if ( $global:midStatus -eq $true )
{
	$deleteFolder    = $midRoot + "\" + $folder
	$binFolder       = $midRoot + "\" + $folder + '\agent\bin\'
	$binStartBat     = $binFolder + 'StartMID-NT.bat'
	$binStopBat      = $binFolder + 'StopMID-NT.bat'
	$binInstallBat   = $binFolder + 'InstallMID-NT.bat'
	$binUnInstallBat = $binFolder + 'UnInstallMID-NT.bat'
	if ( $action -eq "RESTART" )
	{
		Add-Content $myLog "$logTime ACTION MIDSERVER RESTART"
		$output = cmd.exe /c $binStopBat                           
		Add-Content $myLog "$logTime ACTION MIDSERVER STOP $output"
		Write-Output "ACTION MIDSERVER STOP $output"
		$output = cmd.exe /c $binStartBat                           
		Add-Content $myLog "$logTime ACTION MIDSERVER START $output"
		Write-Output "ACTION MIDSERVER START $output"
	}
}

