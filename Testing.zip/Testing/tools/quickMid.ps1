# =============================================================================================================
# Quick command line install (not from SNOW) and start a new Midserver using parameters defined in mid.xml in folder G:\ServiceNow\tools
#
# Parameters:
#    - midSnowName : mid.xml file in tools folder (please first modify manually)
#    - version     : default kingston, others helsinki, jakarta
#    - url         : Can be given, if requirement specific Midserver Download zip
#    - download    : boolean - download or use already downloaded zip, default = true = download
#    - start       : boolean - install (InstallMID-NT.bat )and start (StartMID-NT.bat) the new Midserver, default = true ( = install and start)
#
# Example: .\installMidserver.ps1 mid.xml
#          .\installMidserver.ps1 mid2.xml -download $false -start $false
#
# =============================================================================================================
Param(
  [Parameter(Mandatory=$true)]
  [string]$xmlFile
 ,[Parameter(Mandatory=$false)]
  [string]$version = "kingston"  
 ,[Parameter(Mandatory=$false)]
  [string]$url = ""
 ,[Parameter(Mandatory=$false)]
  [bool]$download = $true
 ,[Parameter(Mandatory=$false)]
  [bool]$start = $true
)
#G:\ServiceNow\tools\defs.ps1
[string]$midRoot  = "G:\ServiceNow\";
[string]$midTools = $midRoot + "tools\"
[string]$myLog    = $midTools + "install.log"
[string]$host     = hostname
$logTime = Get-Date -Format "yyyy-MM-dd hh:mm:ss"


[bool]$global:midStatus = $true
$logTime = Get-Date -Format "yyyy-MM-dd hh:mm:ss"
Add-Content $myLog "$logTime --------------------------------------------------------------------------------------------"
Add-Content $myLog "$logTime CALL PARAM: xmlFile   $xmlFile"
Add-Content $myLog "$logTime      PARAM: Download  $download"
Add-Content $myLog "$logTime      PARAM: Start     $start"
Add-Content $myLog "$logTime      PARAM: Version   $version"

[string]$fullMidXml  = $midTools + "\" + $xmlFile
If ( !(test-path $fullMidXml) )
{
	Write-Output "$logTime Configuration failed, $xmlFile does not exist in tools folder"
	Add-Content $myLog "$logTime Configuration failed, $xmlFile does not exist in tools folder"
	$global:midStatus = $false		
}


# --------------------------------------------
# - Download Midserver zip to a new Midserver folder
# --------------------------------------------

if ( $global:midStatus -eq $true )
{
    G:\ServiceNow\tools\DownloadMidServer $xmlFile -version $version -url $url -download $download
}

# --------------------------------------------
# - parse XML parameters
# --------------------------------------------

if ( $global:midStatus -eq $true )
{
    [string]$folder = ""
    [string]$instance = ""
    [string]$user = ""
    [string]$pw = ""
    [string]$name = ""
    [string]$service = ""
    [string]$display = ""
    [string]$display = ""
    [string]$javaAgent = ""
    [string]$appName = ""
    [string]$tierName = ""
    [string]$nodeName = ""
    
    $rootDir = "G:\ServiceNow\"
    $file = $rootDir + $xmlFile
    [xml]$XmlDocument = Get-Content -Path $fullMidXml
    foreach ( $par in $XmlDocument.Parameters.Parameter )
    {
        $key = $par.name
        $val = $par.value
        if ( $key -eq "folder" )     { $folder    = $val }
        if ( $key -eq "instance" )   { $instance  = $val }
        if ( $key -eq "user" )       { $user      = $val }
        if ( $key -eq "pw" )         { $pw        = $val }
        if ( $key -eq "name" )       { $name      = $val }
        if ( $key -eq "service" )    { $service   = $val }
        if ( $key -eq "display" )    { $display   = $val }
        if ( $key -eq "javaAgent" )  { $javaAgent = $val }
        if ( $key -eq "appName" )    { $appName   = $val }
        if ( $key -eq "tierName" )   { $tierName  = $val }
        if ( $key -eq "nodeName" )   { $nodeName  = $val }
    }
}

# --------------------------------------------
# - configure config.xml
# --------------------------------------------
if ( $global:midStatus -eq $true )
{
    G:\ServiceNow\tools\configureConfigXml.ps1 $folder `
                                               $instance `
                                               $user `
                                               $pw `
                                               "$name"
}
                            
# --------------------------------------------
# - configure wrapper-override.conf
# --------------------------------------------
if ( $global:midStatus -eq $true )
{
    G:\ServiceNow\tools\configureOverride.ps1  $folder `
                                               $service `
                                               "$display" `
                                               "$display" `
                                               $javaAgent `
                                               $appName `
                                               $tierName `
                                               "$nodeName"
}
                            
# --------------------------------------------
# - install and start Midserver
# --------------------------------------------
if ( $global:midStatus -eq $true )
{
    if ( $start -eq $true )
    {
        $binFolder     = $midRoot + "\" + $folder + '\agent\bin\'
        $binInstallBat = $binFolder + 'InstallMID-NT.bat'
        $binStartBat   = $binFolder + 'StartMID-NT.bat'
		Add-Content $myLog "$logTime InstallMID-NT.bat"
        $output = cmd.exe /c $binInstallBat                           
		Add-Content $myLog "$logTime $output"
		Add-Content $myLog "$logTime StartMID-NT.bat"
        $output = cmd.exe /c $binStartBat                    
		Add-Content $myLog "$logTime $output"
    }
}

# --------------------------------------------
# - Write install status
# --------------------------------------------
if ( $global:midStatus -eq $true )
{	
	$logTime = Get-Date -Format "yyyy-MM-dd hh:mm:ss"
	[string]$createdBy = $midRoot + $folder + "\CreatedByQuickMid.txt"
    if ( $start -eq $true )
    {
		Write-Output "MidServer $name installed and started"
		Add-Content $myLog "$logTime $name installed and started"
	}
	else
    {
		Write-Output "MidServer $name created"
		Add-Content $myLog "$logTime $name created"
		Add-Content $createdBy "$logTime created from Midserver $midSnowName"
	}
}
                                   